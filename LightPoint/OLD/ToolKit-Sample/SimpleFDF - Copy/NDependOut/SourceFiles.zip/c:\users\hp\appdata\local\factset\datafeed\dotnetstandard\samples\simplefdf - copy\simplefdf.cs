﻿using FactSet.Datafeed;
using System;

namespace Simple {
    class Program {

        private static bool keepRunning = true;

        private static void PrintAllFields(RTSubscription sub, RTMessage msg, RTRecord rec) {
            if (msg.IsError) {
                Console.WriteLine($"Error for {msg.Key}: {msg.ErrorDescription}");
                keepRunning = false;
                return;
            } else if (msg.IsClosed) {
                Console.WriteLine($"Message for {msg.Key} is marked as closed");
                keepRunning = false;
                return;
            }

            Console.WriteLine($"Message number {sub.Count} for {sub.Key}:");
            foreach (RTFidField fld in msg) {
                string fieldName = RTFieldMap.GetFieldName(fld.Id);
                Console.WriteLine($"\t{fieldName}[{fld.Id}]: {fld.Value}");
            }

            // Alternate syntax to accomplish the same thing:

            //Console.WriteLine($"Message number {sub.Count} for {sub.Key}:");
            //for (int i = 0; i < msg.Count; i++) {
            //    string contents = msg.GetByIndex(i, out int fid);
            //    string fieldName = fieldMap.GetFieldName(fid);
            //    Console.WriteLine($"\t{fieldName}[{fid}]: {contents}");
            //}
        }

        static void Main(string[] args)
        {
            // Intercept sigint and cleanup before exiting
            Console.CancelKeyPress += delegate (object sender, ConsoleCancelEventArgs e) {
                e.Cancel = true;
                keepRunning = false;
            };

            // Parse arguments
            OnMessageDelegate cb = PrintAllFields;
            string ticker = "FDS-USA";
            if (args.Length < 1) {
                Console.WriteLine("Usage: SimpleFDF.dll <user-serial>:<password>@<hostname> <ticker>");
                return;
            }
            if (args.Length >= 2) {
                ticker = args[1];
            }

            // Create a field map
            try {
                RTFieldMap.Create("../../../../etc/rt_fields.xml");
            } catch (DatafeedException e) {
                Console.WriteLine($"Error while creating fieldmap, was the filename and path correct? Error message:\n\t{e.Message}");
                return;
            }

            RTRequest req = null;

            try { // Many FDF methods can throw Datafeed Exceptions

                // Set the connection info
                try {
                    FDF.ConnInfo = args[0];
                } catch (DatafeedException e) {
                    Console.WriteLine($"Error while setting connection info: {Enum.GetName(typeof(ErrorCode), e.ErrorCode)}");
                    if (e.ErrorCode == ErrorCode.Inval) {
                        Console.WriteLine($"Expected format for connection string is <user-serial>:<password>@<hostname> , was {args[0]}");
                    }
                    return;
                }

                // Connect to the server using that connection info
                FDF.Connect();

                // Make our request
                req = new RTRequest("FDS1", ticker);
                RTSubscription sub = FDF.Request(req, cb);

                // Dispatch until sigint
                while (keepRunning) {
                    FDF.Dispatch(1000);
                }

                // Clean up resources
                FDF.Cancel(sub); // This isn't necessary, it would be canceled
                                 // automatically with a disconnect but this
                                 // shows how to cancel a subscription
                FDF.Disconnect();
            } catch (DatafeedException e) {
                Console.WriteLine($"The sample encountered an exception with errorcode {Enum.GetName(typeof(ErrorCode), e.ErrorCode)}:\n{e}");
                return;
            } finally {
                req?.Dispose(); // All of the types with .Dispose() also support "using ()" syntax
                RTFieldMap.Destroy();
            }

            Console.WriteLine("Good-bye");
        }
    }
}
